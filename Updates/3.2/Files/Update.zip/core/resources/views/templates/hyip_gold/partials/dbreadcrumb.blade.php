<div class="d-flex mb-30 flex-wrap gap-3 justify-content-between align-items-center">
    <h6 class="page-title">{{ __($pageTitle) }}</h6>
    @stack('breadcrumb-plugins')
</div>
